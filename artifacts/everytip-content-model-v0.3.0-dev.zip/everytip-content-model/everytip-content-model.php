<?php
/**
 * Plugin Name: EveryTip Content Model
 * Description: Staging-first ACF offer and bookmaker fields with a capability-checked editorial read endpoint.
 * Version: 0.3.0-dev
 * Requires Plugins: advanced-custom-fields-pro
 * Text Domain: everytip-content-model
 */

defined( 'ABSPATH' ) || exit;

/**
 * Additional offer and bookmaker fields. These complement, rather than
 * replace, the three existing pilot field groups. None uses default WP REST.
 */
function everytip_register_offer_fields() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	acf_add_local_field_group(
		array(
			'key'                => 'group_everytip_offer_public_v1',
			'title'              => 'EveryTip Offer Publishing',
			'fields'             => array(
				array( 'key' => 'field_et_offer_uid_v1', 'label' => 'Stable offer ID', 'name' => 'et_offer_uid', 'type' => 'text', 'required' => 1, 'instructions' => 'Internal permanent ID; do not change after this offer is used.', 'show_in_graphql' => 1 ),
				array( 'key' => 'field_et_offer_status_v1', 'label' => 'Offer status', 'name' => 'et_offer_status', 'type' => 'select', 'choices' => array( 'draft' => 'Draft', 'active' => 'Active', 'paused' => 'Paused', 'expired' => 'Expired' ), 'default_value' => 'draft', 'required' => 1, 'show_in_graphql' => 1 ),
				array( 'key' => 'field_et_offer_cta_v1', 'label' => 'CTA label', 'name' => 'et_offer_cta_label', 'type' => 'text', 'maxlength' => 80, 'show_in_graphql' => 1 ),
				array( 'key' => 'field_et_offer_highlight_v1', 'label' => 'Offer highlight (optional)', 'name' => 'et_offer_highlight', 'type' => 'text', 'maxlength' => 120, 'instructions' => 'Short promotion-specific hook only. Not a substitute for exact terms or eligibility.', 'show_in_graphql' => 1 ),
				array( 'key' => 'field_et_offer_eligibility_v1', 'label' => 'Customer eligibility', 'name' => 'et_offer_eligibility', 'type' => 'textarea', 'rows' => 3, 'show_in_graphql' => 1 ),
				array( 'key' => 'field_et_offer_countries_in_v1', 'label' => 'Included country codes', 'name' => 'et_offer_countries_include', 'type' => 'text', 'instructions' => 'Comma-separated ISO 3166-1 alpha-2 codes, e.g. GB,IE. Blank means no countries approved; it does not mean worldwide.', 'show_in_graphql' => 1 ),
				array( 'key' => 'field_et_offer_countries_out_v1', 'label' => 'Excluded country codes', 'name' => 'et_offer_countries_exclude', 'type' => 'text', 'instructions' => 'Comma-separated ISO 3166-1 alpha-2 codes.', 'show_in_graphql' => 1 ),
				array( 'key' => 'field_et_offer_starts_v1', 'label' => 'Starts at', 'name' => 'et_offer_starts_at', 'type' => 'date_time_picker', 'display_format' => 'd/m/Y H:i', 'return_format' => 'c', 'instructions' => 'WordPress site time zone; leave blank until verified.', 'show_in_graphql' => 1 ),
				array( 'key' => 'field_et_offer_ends_v1', 'label' => 'Ends at', 'name' => 'et_offer_ends_at', 'type' => 'date_time_picker', 'display_format' => 'd/m/Y H:i', 'return_format' => 'c', 'instructions' => 'WordPress site time zone; do not guess an expiry.', 'show_in_graphql' => 1 ),
				array( 'key' => 'field_et_offer_checked_v1', 'label' => 'Last checked', 'name' => 'et_offer_last_checked', 'type' => 'date_picker', 'display_format' => 'd/m/Y', 'return_format' => 'Y-m-d', 'show_in_graphql' => 1 ),
			),
			'location'           => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'et_offer' ) ) ),
			'active'             => true,
			'show_in_rest'       => 0,
			'show_in_graphql'    => true,
			'graphql_field_name' => 'EveryTipOfferPublishing',
		)
	);

	acf_add_local_field_group(
		array(
			'key'                => 'group_everytip_bookmaker_editorial_v1',
			'title'              => 'EveryTip Bookmaker Editorial',
			'fields'             => array(
				array(
					'key'             => 'field_et_bookmaker_usps_v1',
					'label'           => 'Bookmaker USPs (optional)',
					'name'            => 'et_bookmaker_usps',
					'type'            => 'repeater',
					'min'             => 0,
					'max'             => 3,
					'layout'          => 'table',
					'instructions'    => 'Evergreen editorial strengths only. Recheck claims when the bookmaker changes; leave empty to hide.',
					'show_in_graphql' => 1,
					'sub_fields'      => array(
						array( 'key' => 'field_et_bookmaker_usp_text_v1', 'label' => 'USP text', 'name' => 'text', 'type' => 'text', 'required' => 1, 'maxlength' => 120, 'show_in_graphql' => 1 ),
					),
				),
			),
			'location'           => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'et_bookmaker' ) ) ),
			'active'             => true,
			'show_in_rest'       => 0,
			'show_in_graphql'    => true,
			'graphql_field_name' => 'EveryTipBookmakerEditorial',
		)
	);

	acf_add_local_field_group(
		array(
			'key'             => 'group_everytip_offer_private_v1',
			'title'           => 'EveryTip Offer Verification (Private)',
			'fields'          => array(
				array( 'key' => 'field_et_offer_source_v1', 'label' => 'Offer source URL', 'name' => 'et_offer_source_url', 'type' => 'url' ),
				array( 'key' => 'field_et_offer_checked_by_v1', 'label' => 'Checked by', 'name' => 'et_offer_checked_by', 'type' => 'user', 'role' => array( 'administrator', 'editor' ), 'return_format' => 'id' ),
				array( 'key' => 'field_et_offer_notes_v1', 'label' => 'Compliance notes', 'name' => 'et_offer_compliance_notes', 'type' => 'textarea', 'rows' => 4 ),
			),
			'location'        => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'et_offer' ) ) ),
			'active'          => true,
			'show_in_rest'    => 0,
			'show_in_graphql' => false,
		)
	);
}
add_action( 'acf/init', 'everytip_register_offer_fields' );

/**
 * A Gutenberg placement block holds a reference, not duplicated offer copy.
 * Astro will resolve the approved offer and terms through its typed data layer.
 */
function everytip_register_offer_slot_block() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}
	register_block_type( __DIR__ . '/blocks/offer-slot' );
	acf_add_local_field_group(
		array(
			'key'    => 'group_everytip_offer_slot_v1',
			'title'  => 'EveryTip Offer Slot',
			'fields' => array(
				array( 'key' => 'field_et_slot_offer_v1', 'label' => 'Offer', 'name' => 'et_slot_offer', 'type' => 'post_object', 'post_type' => array( 'et_offer' ), 'return_format' => 'id', 'required' => 1, 'instructions' => 'Choose the central offer record. Headline, destination and terms are never copied into this block.' ),
				array( 'key' => 'field_et_slot_layout_v1', 'label' => 'Layout', 'name' => 'et_slot_layout', 'type' => 'select', 'choices' => array( 'inline' => 'Inline card', 'compact' => 'Compact card' ), 'default_value' => 'inline', 'required' => 1 ),
				array( 'key' => 'field_et_slot_heading_v1', 'label' => 'Context heading (optional)', 'name' => 'et_slot_heading', 'type' => 'text', 'maxlength' => 100 ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'acf/everytip-offer-slot' ) ) ),
			'active' => true,
			'show_in_rest' => 0,
			'show_in_graphql' => false,
		)
	);
}
add_action( 'acf/init', 'everytip_register_offer_slot_block' );

/**
 * The first REST slice is read-only. A write route must have optimistic
 * concurrency, field validation, revisions and read-back before activation.
 */
function everytip_offer_api_permission( $request ) {
	$id = absint( $request['id'] );
	if ( 'et_offer' !== get_post_type( $id ) ) {
		return new WP_Error( 'everytip_offer_not_found', 'Offer not found.', array( 'status' => 404 ) );
	}
	if ( ! current_user_can( 'edit_post', $id ) ) {
		return new WP_Error( 'everytip_offer_forbidden', 'Insufficient editorial permission.', array( 'status' => 403 ) );
	}
	return true;
}

function everytip_offer_api_read( $request ) {
	$id = absint( $request['id'] );
	$post = get_post( $id );
	if ( ! $post || ! function_exists( 'get_field' ) ) {
		return new WP_Error( 'everytip_offer_unavailable', 'Offer fields unavailable.', array( 'status' => 503 ) );
	}

	$fields = array();
	foreach ( array( 'et_offer_uid', 'et_offer_status', 'et_offer_cta_label', 'et_offer_highlight', 'et_offer_eligibility', 'et_offer_countries_include', 'et_offer_countries_exclude', 'et_offer_starts_at', 'et_offer_ends_at', 'et_offer_last_checked', 'public_headline', 'compact_terms', 'full_terms' ) as $name ) {
		$fields[ $name ] = get_field( $name, $id );
	}

	return rest_ensure_response(
		array(
			'id'           => $id,
			'title'        => get_the_title( $id ),
			'status'       => $post->post_status,
			'modified_gmt' => $post->post_modified_gmt,
			'fields'       => $fields,
		)
	);
}

function everytip_register_offer_api() {
	register_rest_route(
		'everytip/v1',
		'/offer/(?P<id>\d+)',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'everytip_offer_api_read',
			'permission_callback' => 'everytip_offer_api_permission',
			'args'                => array( 'id' => array( 'required' => true, 'type' => 'integer', 'minimum' => 1 ) ),
		)
	);
}
add_action( 'rest_api_init', 'everytip_register_offer_api' );
