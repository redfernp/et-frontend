# EveryTip Content Model (staging-first)

Version-controlled ACF offer/bookmaker fields and a capability-checked, read-only REST route. This complements the three pilot ACF groups already present on staging; it does not enable their public REST exposure or add public offers.

The plugin registers public offer-publishing fields in WPGraphQL and keeps verification fields out of both public GraphQL and default REST. Version 0.2 adds optional bookmaker-level USPs (up to three) and an optional offer-specific highlight; these are editorial copy, separate from offer terms. `GET /wp-json/everytip/v1/offer/{id}` requires an authenticated user with `edit_post` capability and returns only an allowlist of editorial fields, never the affiliate destination. Anonymous access must fail. There is deliberately no write route yet: writes need explicit validation, optimistic concurrency, revisions and a round-trip test with each person's credentials.

Do not deploy to live or enter real offers until the staging schema, country fail-closed behaviour, revision strategy and terms approval have passed review. ACF field groups registered via PHP are not editable in the ACF Field Groups UI; change this source and redeploy instead.

## Next local block slice (not deployed)

Local version `0.3.0-dev` adds `blocks/offer-slot/` as a Gutenberg/ACF placement prototype. Staging still runs v0.2. It lets Eric select one central `et_offer` record, an approved card layout and an optional contextual heading. The block renders only a data marker; it never embeds an affiliate URL, headline or terms in the post body. Astro must resolve the marker against its typed offer feed and fail closed for unapproved, expired or geographically ineligible offers. This code has not yet been uploaded to staging or tested in the WordPress editor. Before deployment, verify the installed ACF Pro version, create a staging draft, inspect WPGraphQL `content`, and test the Astro resolver. Do not publish a page that still contains a marker.
