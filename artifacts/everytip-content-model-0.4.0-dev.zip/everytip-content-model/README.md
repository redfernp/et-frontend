# EveryTip Content Model (staging-first)

Version-controlled ACF offer/bookmaker fields and a capability-checked, read-only REST route. This complements the three pilot ACF groups already present on staging; it does not enable their public REST exposure or add public offers.

The plugin registers public offer-publishing fields in WPGraphQL and keeps verification fields out of both public GraphQL and default REST. Version 0.2 adds optional bookmaker-level USPs (up to three) and an optional offer-specific highlight; these are editorial copy, separate from offer terms. `GET /wp-json/everytip/v1/offer/{id}` requires an authenticated user with `edit_post` capability and returns only an allowlist of editorial fields, never the affiliate destination. Anonymous access must fail. There is deliberately no write route yet: writes need explicit validation, optimistic concurrency, revisions and a round-trip test with each person's credentials.

Do not deploy to live or activate offers until the staging schema, country fail-closed behaviour, revision strategy and terms approval have passed review. ACF field groups registered via PHP are not editable in the ACF Field Groups UI; change this source and redeploy instead.

## Gutenberg offer-slot prototype

Version `0.3.0-dev` added `blocks/offer-slot/`, a Gutenberg/ACF placement prototype now installed on staging. It lets Eric select one central `et_offer` record, an approved card layout and an optional contextual heading. The block renders only a data marker; it never embeds an affiliate URL, headline or terms in the post body. A staging draft round-trip proved REST and WPGraphQL retain the reference. Astro must still resolve the marker against its typed offer feed and fail closed for unapproved, expired or geographically ineligible offers. Do not publish a page that still contains an unresolved marker.

## Local v0.4.0-dev field (not yet deployed)

JP approved the short disclosures on the live free-bets page as the space-restricted offer terms. The local plugin source adds `et_offer_full_terms_url` as an optional offer-specific URL for direct access to the operator's full terms. This avoids pasting the complete legal text into ACF and does not replace the short terms or affiliate destination. It is exposed through the authenticated editorial read route and, after the plugin update, WPGraphQL. Staging still runs v0.3.0-dev until this update is explicitly approved, uploaded and checked. The frontend GraphQL query and activation gate must not rely on the field until that rollout succeeds.
